# Download verification

- Slurm job 14697715 completed successfully on node o05c01; scheduler elapsed time 00:05:52 (excludes queue time).
- The saved job log identifies NVIDIA A100-SXM4-80GB. See slurm-14697715.log.
- All 13 trials completed. Every trial has 63 distinct J-Lens layers, ten finite readouts per token position, and matching prompt/generated token counts.
- All steered trials recorded interval caps at exactly the configured layers, with matching half-width fractions and finite ordered bounds. Zero-width intervals have equal endpoints. Character-centre vector provenance is present.
- Two responses reached the 256-token limit; their endings may be truncated.
- Sum of recorded per-trial durations: 171.05 seconds; this excludes shared setup/model loading.
- Submitted isolated checkout was pinned to 4ebe8b0e2fe79a96cc143b734e873591b61ce891. Runtime metadata has null Git revision/dirty fields; these fields have not been filled in retrospectively.
- Original JSON/configuration/provenance files remain unchanged. Only report.html was refreshed locally. This note and the job log were added during download verification.
