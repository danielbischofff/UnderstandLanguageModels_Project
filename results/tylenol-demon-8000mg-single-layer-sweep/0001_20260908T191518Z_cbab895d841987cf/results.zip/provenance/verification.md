# Download verification

- Slurm job 14693599 completed successfully on node o05c01; scheduler elapsed time 00:07:05 (excludes queue time).
- The saved job log identifies NVIDIA A100-SXM4-80GB. See slurm-14693599.log.
- All 19 trials completed. Every trial has 63 distinct J-Lens layers, ten finite readouts per token position, and matching prompt/generated token counts.
- Six responses reached the 256-token limit; their endings may be truncated.
- Sum of recorded per-trial durations: 258.35 seconds; this excludes shared setup/model loading.
- Submitted source: 2da314082998c1349cb1e5ad3bb5f33751dda250, recorded at submission. Runtime metadata has null Git revision/dirty fields; these fields have not been filled in retrospectively.
- Original JSON/configuration/provenance files remain unchanged. Only report.html was refreshed locally. This note and the job log were added during download verification.
